package Graphs;

public class Connection {

    private City city;
    private Integer distance;

    public Connection(City city, Integer distance) {
        this.city = city;
        this.distance = distance;
    }

}
